//LEMBRE-SE QUE VOCÊ DEVE RODAR ESSE CÓDIGO NO ARQUIVO main.dart
import "dart:io";

//PACIENTE = ["NOME","IDADE","GRAU_DE_GRAVIDADE"]
void main() {
  print("ATENDIMENTO DO HOSPITAL PAZ MUNDIAL\n");

	String cmd = "-1";
  List<List<String>> bd = List<List<String>>();

  while (cmd != "3"){
    print("1. Cadastrar novo paciente");
    print("2. Chamar paciente na fila");
    print("3. Encerrar programa");
    cmd = stdin.readLineSync();
    if (cmd == "1"){
      List<String> novoUsuario = List<String>();

      // Pede o nome
      print("Qual o nome do paciente?");
      String nome = stdin.readLineSync();

      // Pede a idade
      print("Qual a idade do paciente?");
      String idadeSTR = stdin.readLineSync();

      // Pede o Grau de Gravidade
      print("Qual o grau de gravidade do caso?");
      String grauSTR = stdin.readLineSync();

      novoUsuario.add(nome);
      novoUsuario.add(idadeSTR);
      novoUsuario.add(grauSTR);

      //Adiciona da fila
      if(bd.length == 0){
        bd.add(novoUsuario);
      }else{
        // [[ricarth,25,2], [warley,21,1],[monalisa,24,0]]
        // [[ricarth,25,2]]
        int i = 0;
        while(i < bd.length){
          if (int.parse(bd[i][2]) > int.parse(novoUsuario[2])){
            i++;
          }else if (bd[i][2] == novoUsuario[2]){
            if(int.parse(bd[i][1]) > int.parse(novoUsuario[1])){
              i++;
            }else if (int.parse(bd[i][1]) == int.parse(novoUsuario[1])){
              i++;
              break;
            }else{
              break;
            }
          }else{
            break;
          }          
        }
        bd.insert(i,novoUsuario);
      }
      
      print("PACIENTE CADASTRADO NA FILA");

    }else if (cmd == "2"){
      //Verificar se a lista está vazia
      if (bd.length == 0){
        print("SEM PACIENTES NO MOMENTO");
      }else{
        //Mostrar o paciente 0 na tela
        print("Nome: " + bd[0][0]);
        print("Idade: " + bd[0][1]);
        print("Gravidade: " + bd[0][2]);

        //Remover paciente 0
        bd.removeAt(0);
      }
      
    }else if (cmd == "3"){
      print("PROGRAMA ENCERRADO");
    }else{
      print("Comando incorreto.");
    }
    print("----------------------------\n");
  }  
  
}