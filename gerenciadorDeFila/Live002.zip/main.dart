class Empresa{
  String nome;
  String cnpj;

  Empresa({this.nome, this.cnpj});

  String nomeEmCaixaAlta(){
    return this.nome.toUpperCase();
  }

  String toString(){
    return "Nome: " + nomeEmCaixaAlta() + "\n" + "CNPJ: " + cnpj;
  }
}

class Pessoa{
  String nome;
  int idade;
  String cpf;
  Empresa empresa;
  double salario;

  Pessoa({this.nome, this.idade, this.cpf, this.empresa, this.salario}); 

  void aumentoSalario(double valor){
    this.salario = this.salario + valor;
  }

  String toString(){
    return "Nome: " + this.nome + "\nIdade:" + this.idade.toString() + "\nCPF: " + this.cpf + "\n------------------------\nINFORMAÇÕES DA EMPRESA:\n"+ this.empresa.toString(); 
  }
}

void main() {
  Empresa empresa01 = Empresa(nome: "Dotcode Education LTDA Se inscreve", cnpj: "75.400.086/0001-49");

  //Pessoa empregado;
  //empregado = Pessoa();
  //empregado.nome = "Ricarth";

  Pessoa empregado = Pessoa(nome: "Ricarth");
  empregado.idade = 24;
  empregado.cpf = "851.768.960-79";
  empregado.empresa = empresa01;
  empregado.salario = 1500;

  empregado.aumentoSalario(250);

  print(empregado.salario);
}